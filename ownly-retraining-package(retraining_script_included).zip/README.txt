Ownly - model retraining package
================================
Start with docs/RETRAINING_GUIDE.md (steps, Excel format, how the model is replaced).

Excel files (Backend/model/sample/)
  retraining_template.xlsx      empty template with an Instructions sheet
  retraining_sample_data.xlsx   60 products, 15 months of made-up history

Run (from the Backend folder)
  npm install
  npm run ai:retrain -- --excel model/sample/retraining_sample_data.xlsx --dry-run
  npm run ai:retrain -- --excel model/sample/retraining_sample_data.xlsx
  npm run ai:retrain -- --status        # which model is live
  npm run ai:retrain -- --rollback      # undo

Code: Backend/src/retraining/, Backend/src/scripts/ai-retrain.ts,
      Backend/src/services/ai/model-registry.ts (new)
      Backend/src/services/ai/ai-scoring.ts, ai.service.ts (modified - swappable model settings)
Tests: Backend/tests/retraining.test.ts
Needs: exceljs (already in package.json) and the app's database (Backend/.env).
